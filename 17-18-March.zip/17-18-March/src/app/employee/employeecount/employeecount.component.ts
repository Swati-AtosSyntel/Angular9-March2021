import { Component, Input,Output,EventEmitter,OnInit } from '@angular/core';

@Component({
  selector: 'app-employeecount',
  templateUrl: './employeecount.component.html',
  styleUrls: ['./employeecount.component.css']
})
export class EmployeecountComponent implements OnInit {
  @Input()
  All:number;
  @Input()
  Male:number;
  @Input()
  Female:number;

  selectedRadioButtonValue:string="All";

  @Output()
  countRadioButtonSelectionChanged:EventEmitter<string>=new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }
  onRadioButtonSelectionChange(){
    this.countRadioButtonSelectionChanged.emit(this.selectedRadioButtonValue);
    console.log(this.selectedRadioButtonValue);
  }

}
