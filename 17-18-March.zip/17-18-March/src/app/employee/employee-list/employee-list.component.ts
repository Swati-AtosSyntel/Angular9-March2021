import { Component, OnInit } from '@angular/core';
import {EmployeeServiceService} from './employee-service.service'
import {IEmployee} from './employee';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  providers:[EmployeeServiceService]
})
export class EmployeeListComponent implements OnInit {
employees:IEmployee[];
statusMessage:string="Loading Data ....Please wait...";
selectedEmployeeCountRadioButton:string="All";
  constructor(private _employeeService:EmployeeServiceService) { }

  ngOnInit(): void {
    this.employees=this._employeeService.getEmployees();
  }
  getAllEmployeesCount():number{
    return   this.employees.length;
  }
  getMaleEmployeeCount():number{
    return this.employees.filter(e=>e.gender=="Male").length;
  }
  getFemaleEmployeeCount():number{
    return this.employees.filter(e=>e.gender=="Female").length;
  }
  onEmployeeCountRadioButtonChange(selectedRadioButtonValue:string):void{
    this.selectedEmployeeCountRadioButton=selectedRadioButtonValue;
  }

}
