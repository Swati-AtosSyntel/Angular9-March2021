import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Repos} from './repos';
@Component({
  selector: 'app-httpclient',
  templateUrl: './httpclient.component.html',
  styleUrls: ['./httpclient.component.css']
})
export class HttpclientComponent implements OnInit {

  userName:string="Swati";
  baseUrl:string="https://api.github.com";
  repos:Repos[];
  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.getRepository();
  }

  public getRepository(){
    return this.http.get<Repos[]>(
      this.baseUrl + '/users/' +this.userName+'/repos'
    ).subscribe(
      (response)=>{
        console.log("response received");
        console.log(response);
        this.repos=response;
      },
      (error)=>{
        console.error("Request failed with error");
        alert(error.statusMessage);
      },
      ()=>{
        console.log("Request Completed");
      }
    )
  }

}
