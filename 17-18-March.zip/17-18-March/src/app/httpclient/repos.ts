export class Repos{
    id:string;
    name:string;
    htmlUrl:string;
    description:string;
}