import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import {GenderPipe} from './gender.pipe';
import { EmployeeListComponent } from './employee/employee-list/employee-list.component';
import { EmployeecountComponent } from './employee/employeecount/employeecount.component';
import { HttpclientComponent } from './httpclient/httpclient.component';
import {HttpClientModule} from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,GenderPipe, EmployeeListComponent, EmployeecountComponent, HttpclientComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
