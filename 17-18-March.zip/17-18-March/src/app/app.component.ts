import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:`<h1>
  //{{title}}
  //</h1>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to Angular Single Page Application ';
isSelected:boolean;
colors=['Red','Green','Blue','Orange'];
show=true;
num=1;

constructor(){
  this.isSelected=false;
}
  changeTitle(){
    this.title="Angular is used for Single Page Application Development";
  }
}
